function model = train_lr(X, y, tolerance, step_size, reg_str, maxIters)

x = X;
% TRAIN function for logistic regression.

% X_categorical is the matrix of categorical predictors, with rows corresponding to examples
% X_continuous is the matrix of continuous predictors, with rows corresponding to examples
% y is the column of corresponding class. I presume the values of y are 0 or 1
% reg_str is the regularization strength (DO NOT CHANGE)

% To train, I use simple gradient ascend as described in the slides.

% m examples, n predictors
	[n, m] = size(x);
	
	% adding a column of ones to x as a dummy variable
	x = [ones([n, 1]) x];

	% w is a column vector
	w = zeros(m+1, 1) + 0.01;
	iter = 0;

	% Gradient ascent

	[gr, LL] = loglikelihood(x, y, w, reg_str);

	normGr = norm(gr);

	while normGr > tolerance && iter <= maxIters
		
		iter = iter + 1;
		
		w = w + step_size * gr;
		[gr, LL] = loglikelihood(x, y, w, reg_str);
		
		normGr = norm(gr);
	end
	model.w = w;
end


function [gr, LL] = loglikelihood(data, y, w, reg_str)
	[~, n] = size(data);

	prods = data * w;

	LL = sum(y .* prods - log(1 + exp(1).^prods));

	reg = 2*w;

	%--You should not regularize over the intercept--%
	% reg(1) = 0;
	%------------------------------------------------%
	gr = data .* repmat((y - (1+exp(1) .^ (- prods)).^(-1)), 1, n);
	gr = sum(gr);


	gr = gr'+reg_str*reg;
end
