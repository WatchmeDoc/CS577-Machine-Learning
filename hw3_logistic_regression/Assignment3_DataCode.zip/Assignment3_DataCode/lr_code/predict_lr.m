function predictions = predict_lr(model, X)

	x = X;
	n = size(x,1);
	x = [ones([n, 1]) x];
	probs = 1 ./ (1 + exp(1).^ (-x * model.w));
	predictions = (probs >= 0.5);
end