data = [normrnd(0,1,[100 5]);normrnd(2,2,[100 5])];

target = ones([200 1]);
all_inds = logical(target);
target(1:100) = 0;


[train,idx] = datasample(data, 150,'Replace',false);
all_inds(idx) = 0;

model = train_lr(train, target(idx), 1e-4, 1e-3, 1e-4, 200);

predictions = predict_lr(model,data(all_inds,:));

accuracy = 1-nnz(target(all_inds==1)- predictions)/nnz(all_inds)
